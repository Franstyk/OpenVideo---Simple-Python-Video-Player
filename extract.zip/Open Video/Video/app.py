import tkinter as tk
from tkinter import ttk
from moviepy.editor import VideoFileClip
from PIL import Image, ImageTk
import threading

vplayp = input("Wpisz ścieżkę wideo: ")

# Zmienna globalna do przechowywania obiektu wideo
clip = None

def play_video():
    global clip
    def play():
        global clip
        clip = VideoFileClip(vplayp)  # Podaj ścieżkę do twojego wideo
        clip.preview(fps=clip.fps)  # Odtwarzanie wideo z dźwiękiem

    thread = threading.Thread(target=play)
    thread.start()

def stop_video():
    global clip
    if clip is not None:
        clip.close()
        clip = None

root = tk.Tk()
root.title("Open Video - Iterfejs")

label = ttk.Label(root)
label.pack()

play_button = ttk.Button(root, text="Odtwórz Wideo", command=play_video)
play_button.pack()

stop_button = ttk.Button(root, text="Stop", command=stop_video)
stop_button.pack()

root.mainloop()
